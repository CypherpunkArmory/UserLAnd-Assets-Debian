use strict;
use warnings;
package perlfaq;
$perlfaq::VERSION = '5.021010';
1;
